#!/usr/bin/env expect -f
set timeout -1

set username [lindex $argv 0];
set password [lindex $argv 1];

spawn pod update

expect {
    "Username"
    {
        send -- "${username}\r"
        exp_continue
    }
    "Password"
    {
        send -- "${password}\r"
        exp_continue
    }
}
