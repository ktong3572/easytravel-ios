import XCTest
import MonitoringTools
@testable import Dynatrace
@testable import DynatraceSessionReplay

class NetworkAcceptanceTest: EarlGreySessionSimulation {

    func testNetworkBandwidthAcceptance() {
        container().getConfigurationController().getCurrentTrackingConfiguration().setMinDataJobSize(100000)
        container().getConfigurationController().getCurrentTrackingConfiguration().setMinDataJobTime(100000)

        entireSessionSimulation()

        Dynatrace.identifyUser("\(UIDevice.current.name) - \(UIDevice.current.systemVersion)")
        Dynatrace.flushEvents()
        wait(for: 40)
    }
}
