import XCTest
import EarlGrey
@testable import Dynatrace
@testable import DynatraceSessionReplay

class LoadGenerator: EarlGreySessionSimulation {

    func testInit() {
        GREYConfiguration.sharedInstance().setValue(true, forConfigKey: kGREYConfigKeySynchronizationEnabled)
        setUpTracker()
        if waitForTestAlert(timeout: 10) {
            acceptStage()
            setHostStage()
        } else {
            XCTFail()
        }
    }

    func testMonica() {
        GREYConfiguration.sharedInstance().setValue(true, forConfigKey: kGREYConfigKeySynchronizationEnabled)
        let user = LoadGeneratorTestUser(name: "monica",
                                         password: "monica",
                                         destination: "Paris")
        if waitForTestAlert(timeout: 10) {
            Dynatrace.identifyUser(user.name.capitalized)

            checkTermsOfUseStage()
            loginStage(user.name, user.password)
        }
    }

    func testMaria() {
        let user = LoadGeneratorTestUser(name: "maria",
                                         password: "maria",
                                         destination: "Paris")
        runTestWithCrash(for: user)
    }

    func testGreta() {
        let user = LoadGeneratorTestUser(name: "greta",
                                         password: "greta",
                                         destination: "Gdańsk")
        runTestWithCrash(for: user)
    }

    func testSilvia() {
        let user = LoadGeneratorTestUser(name: "silvia",
                                         password: "silvia",
                                         destination: "París ")
        runTestWithCrash(for: user)
    }

    func testWithoutCrash() {
        if waitForTestAlert(timeout: 10) {
            acceptStage()
            checkTermsOfUseStage()

            tearDownTracker()
        } else {
            XCTFail()
        }
    }

    private func setUpTracker() {
        container().getConfigurationController().getCurrentTrackingConfiguration().setMinDataJobSize(100000)
        container().getConfigurationController().getCurrentTrackingConfiguration().setMinDataJobTime(100000)
    }

    private func tearDownTracker() {
        Dynatrace.flushEvents()
        wait(for: 40)
    }

    private func runTestWithCrash(for user: LoadGeneratorTestUser) {
        if waitForTestAlert(timeout: 10) {
            rotateDeviceStage()

            Dynatrace.identifyUser(user.name.capitalized)
            loginStage(user.name, user.password)

            bookJourneyStage(user.destination)
            checkTermsOfUseStage()
        }
    }
}

private struct LoadGeneratorTestUser {
    let name: String
    let password: String
    let destination: String
}
