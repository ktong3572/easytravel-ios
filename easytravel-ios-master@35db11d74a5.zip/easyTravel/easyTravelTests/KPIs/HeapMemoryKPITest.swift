import XCTest
import MonitoringTools

class HeapMemoryKPITest: EarlGreySessionSimulation {

    func testHeapMemoryKpi() {
        var execute = true
        self.measureMetrics(getPerformanceMetrics(from: MonitoringTools.performanceHeapAllocationsMetrics()), automaticallyStartMeasuring: true) {
            if execute {
                self.entireSessionSimulation()
                execute = false
            }
        }
    }

    private func getPerformanceMetrics(from metrics: [String]) -> [XCTPerformanceMetric] {
        return metrics.map{ XCTPerformanceMetric($0) }
    }
}
