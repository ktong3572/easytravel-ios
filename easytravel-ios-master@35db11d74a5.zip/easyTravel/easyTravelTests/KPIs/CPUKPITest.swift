import MonitoringTools
import EarlGrey

class CPUKPITest: EarlGreySessionSimulation {

    var totalCpuUsage: Double = 0
    var totalCpuRequests: Double = 0
    var cpuWaterMark: Double = 0

    override func setUp() {
        super.setUp()

        // Disable automatic synchronization.
        GREYConfiguration.sharedInstance().setValue(false, forConfigKey: kGREYConfigKeySynchronizationEnabled)
    }

    override func tearDown() {
        super.tearDown()

        // Disable automatic synchronization.
        GREYConfiguration.sharedInstance().setValue(true, forConfigKey: kGREYConfigKeySynchronizationEnabled)
    }

    func testCPUConsumptionKPI() {
        let timer = RepeatingTimer(timeInterval: 0.05)
        timer.eventHandler = {
            let cpuUsage = CPUMonitor.usage()
            if cpuUsage > 0 {
                self.totalCpuUsage += cpuUsage
                self.totalCpuRequests += 1
            }

            if !cpuUsage.isLess(than: self.cpuWaterMark) {
                self.cpuWaterMark = cpuUsage
            }
        }
        timer.resume()

        entireSessionSimulation()
        MonitoringTools.sendCPUConsumptionToDummyServer(cpuConsumption: totalCpuUsage / totalCpuRequests)
        wait(for: 2)
    }

}
