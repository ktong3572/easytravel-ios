import XCTest
import MonitoringTools

class FileIOKPITest: EarlGreySessionSimulation {

    let bundleId = "com.dynatrace.demoapps.easyTravel"
    var totalWrites = 0
    var totalReads = 0
    var totalDeletes = 0
    var lastScreenshotsNumber = 0
    var testFinished = false
    var maxFilesInFolder: UInt64 = 2

    let expectation = XCTestExpectation(description: "Number of files should be 0")

    func testFileIOAccessesKPI() throws {
        guard let screenshotsFolder = try MonitoringTools.getScreenshotsFolderForApp() else {
            XCTFail("Unexisting screenshotsFolder")
            return
        }
        let directoryMonitor = DirectoryMonitor(URL: screenshotsFolder)
        directoryMonitor.delegate = self
        directoryMonitor.startMonitoring()

        entireSessionSimulation()

        testFinished = true

        let checkFilesCount = CheckFilesCountWrapClass(folder: screenshotsFolder, maxFilesInFolder: maxFilesInFolder, onFinishHandler: { [weak self] in
            self?.directoryMonitorDidObserveChange(directoryMonitor)
        })

        MonitoringTools.checkFilesCount(checkFilesCountWrapClass: checkFilesCount)

        wait(for: [expectation], timeout: 40)
    }
}

// MARK: - DirectoryMonitorDelegate

extension FileIOKPITest: DirectoryMonitorDelegate {

    func directoryMonitorDidObserveChange(_ directoryMonitor: DirectoryMonitor) {
        let currentScreenshots = directoryMonitor.numberOfFiles()
        let difference = abs(currentScreenshots - lastScreenshotsNumber)
        if currentScreenshots > lastScreenshotsNumber {
            totalWrites += difference
        } else if currentScreenshots < lastScreenshotsNumber {
            totalDeletes += difference
        } else {
            totalReads += 1
        }
        lastScreenshotsNumber = currentScreenshots

        if testFinished && currentScreenshots <= maxFilesInFolder {
            directoryMonitor.stopMonitoring()
            MonitoringTools.sendFileIOAccessesToDummyServer(writes: totalWrites,
                                                            deletes: totalDeletes,
                                                            reads: totalReads)
            wait(for: 2)
            expectation.fulfill()
        }
    }

}
