import MonitoringTools

class LocalStorageKPITest: EarlGreySessionSimulation {

    let bundleId = "com.dynatrace.demoapps.easyTravel"

    func testLocalStorageKpi() {
        entireSessionSimulation()
        MonitoringTools.sendLocalStorageSizeToDummyServer(bundleId: bundleId)
        wait(for: 2)
    }
}
