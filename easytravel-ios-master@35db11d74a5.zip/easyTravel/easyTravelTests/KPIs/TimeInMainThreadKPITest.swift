import XCTest
import MonitoringTools

class TimeInMainThreadKPITest: EarlGreySessionSimulation {

    func testTimeInMainThreadKpi() {
        var execute = true
        self.measureMetrics(getPerformanceMetrics(from: MonitoringTools.performanceTimeMetrics()), automaticallyStartMeasuring: true) {
            if execute {
                self.entireSessionSimulation()
                execute = false
            }
        }
    }

    private func getPerformanceMetrics(from metrics: [String]) -> [XCTPerformanceMetric] {
        return metrics.map{ XCTPerformanceMetric($0) }
    }
}
