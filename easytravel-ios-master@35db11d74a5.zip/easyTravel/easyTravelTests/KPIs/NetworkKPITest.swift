import XCTest
import MonitoringTools

class NetworkKPITest: EarlGreySessionSimulation {

    let bundleId = "com.dynatrace.demoapps.easyTravel"
    let maxFilesInFolder: UInt64 = 2

    let expectation = XCTestExpectation(description: "Folder files should be less than expected max")

    func testNetworkBandwithKpi() throws {
        entireSessionSimulation()
        try calculateScreenshotsFolderSize()
    }

    private func calculateScreenshotsFolderSize() throws {
        guard let screenshotsFolder = try MonitoringTools.getScreenshotsFolderForApp() else {
            XCTFail("Unexisting screenshotsFolder")
            return
        }

        NSLog("PATH = " + screenshotsFolder.absoluteString)

        let checkFilesCount = CheckFilesCountWrapClass(folder: screenshotsFolder, maxFilesInFolder: maxFilesInFolder, onFinishHandler: { [weak self] in
            self?.expectation.fulfill()
        })

        MonitoringTools.checkFilesCount(checkFilesCountWrapClass: checkFilesCount)

        wait(for: [expectation], timeout: 40)
    }
}
