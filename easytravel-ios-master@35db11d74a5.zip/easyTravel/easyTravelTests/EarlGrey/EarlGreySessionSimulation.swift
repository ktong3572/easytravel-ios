import XCTest
import WebKit
import EarlGrey

@testable import DynatraceSessionReplay

class EarlGreySessionSimulation: XCTestCase {

    override func setUp() {
        super.setUp()

        // Disable analytics.
        GREYConfiguration.sharedInstance().setValue(false, forConfigKey: kGREYConfigKeyAnalyticsEnabled)
    }

    func testEarlGreySimulation() {
        entireSessionSimulation()
    }

    func testDebugNormalCrashSimulation() {
        crashSessionSimulation()
    }

    func testDebugKeystrokeCrashSimulation() {
        crashKeystrokesSimulation()
    }
}

// MARK: - EarlGrey

extension EarlGreySessionSimulation {

    func entireSessionSimulation() {
        if GREYConfiguration.sharedInstance().boolValue(forConfigKey: kGREYConfigKeySynchronizationEnabled) {
            automaticSessionSimulation()
        } else {
            manualSessionSimulation()
        }
    }

    private func automaticSessionSimulation() {
        acceptStage()
        rotateDeviceStage()
        setHostStage()
        loginStage()
        bookJourneyStage()
        checkTermsOfUseStage()
        fakeCrashStage()
    }

    func waitForTestAlert(timeout: CFTimeInterval) -> Bool {
        let waitForElement = GREYCondition(name: "Wait element") { () -> Bool in
            var error: NSError?
            let matcher = grey_allOf([grey_text("Dismiss"), grey_interactable()])
            let element = EarlGrey.selectElement(with: matcher)
            element.assert(grey_notNil(), error: &error)
            element.perform(grey_tap())
            return error == nil
        }
        return waitForElement.waitWithTimeout(seconds: timeout)
    }

    private func manualSessionSimulation() {

        // MARK - Accept stage
        wait(for: 1)
        self.acceptStage()
        wait(for: 1)

        // MARK - Rotate stage
        rotateDeviceStage()

        // MARK - Manual Set Host Stage
        tapButton(buttonId: "Settings Button", in: UINavigationBar.self)
        wait(for: 1)
        type(text: "easytravel.lab.dynatrace.org", elementId: "LocalhostField")
        wait(for: 1)
        tapButton(title: "Done", in: UINavigationBar.self)

        // MARK - Manual Login Stage
        wait(for: 1)
        tapButton(buttonId: "LoginCell", in: UITableView.self)
        wait(for: 1)
        type(text: "maria", elementId: "UsernameField")
        wait(for: 1)
        type(text: "maria", elementId: "PasswordField")
        wait(for: 1)
        tapButton(buttonId: "LoginButton", in: UIView.self)
        wait(for: 1)
        tapButton(title: "easyTravel", in: UINavigationBar.self)

        // MARK - Manual Booking Stage
        wait(for: 1)
        tapButton(buttonId: "SearchCell", in: UITableView.self)
        wait(for: 1)
        let textElement = EarlGrey.selectElement(with: grey_kindOfClass(UISearchBar.self)).atIndex(0)
        textElement.perform(grey_tap())
        wait(for: 1)
        textElement.perform(grey_typeText("Pa"))
        wait(for: 2)
        var cell = EarlGrey.selectElement(with: grey_text("Paris"))
        cell.perform(grey_tap())
        wait(for: 2)
        cell = EarlGrey.selectElement(with: grey_text("Palm - Paris"))
        cell.perform(grey_tap())
        wait(for: 1)
        tapButton(title: "Book Journey", in: UIView.self)
        wait(for: 2)
        tapButton(title: "Search", in: UINavigationBar.self)
        wait(for: 1)
        tapButton(title: "Cancel", in: UISearchBar.self)
        wait(for: 1)
        tapButton(title: "easyTravel", in: UINavigationBar.self)

        // MARK - Manual Terms of Use Stage
        wait(for: 1)
        tapButton(buttonId: "TermsOfUseCell", in: UITableView.self)
        wait(for: 4)
        let webView = EarlGrey.selectElement(with: grey_kindOfClass(WKWebView.self))
        webView.perform(grey_swipeSlowInDirection(GREYDirection.up))
        wait(for: 1)
        webView.perform(grey_swipeSlowInDirection(GREYDirection.up))
        wait(for: 1)
        webView.perform(grey_swipeSlowInDirection(GREYDirection.up))
        wait(for: 1)
        tapButton(title: "easyTravel", in: UINavigationBar.self)
        wait(for: 2)

        // MARK - Simulate fake crash POI
        fakeCrashStage()
    }

    private func crashSessionSimulation() {
        acceptStage()
        setHostStage()
        loginStage()
        contactStage()
    }

    private func crashKeystrokesSimulation() {
        acceptStage()
        crashHostStage()
    }
}

// MARK - EarlGrey Session Stages

extension EarlGreySessionSimulation {
    func acceptStage() {
        DTLog(.sessionReplay, "=============********===================")
        DTLog(.sessionReplay, "ACCEPT STAGE")
        DTLog(.sessionReplay, "=============********===================")
        tapButton(buttonId: "I Accept", in: UIView.self, optional: true)
    }

    func rotateDeviceStage() {
        DTLog(.sessionReplay, "=============********===================")
        DTLog(.sessionReplay, "ROTATE DEVICE STAGE")
        DTLog(.sessionReplay, "=============********===================")

        EarlGrey.rotateDeviceTo(orientation: UIDeviceOrientation.landscapeLeft, errorOrNil: nil)
        wait(for: 2)
        EarlGrey.rotateDeviceTo(orientation: UIDeviceOrientation.portrait, errorOrNil: nil)
        wait(for: 1)
    }

    func setHostStage() {
        DTLog(.sessionReplay, "=============********===================")
        DTLog(.sessionReplay, "HOST STAGE")
        DTLog(.sessionReplay, "=============********===================")
        tapButton(buttonId: "Settings Button", in: UINavigationBar.self)
        type(text: "ec2-34-243-40-80.eu-west-1.compute.amazonaws.com", elementId: "LocalhostField")
        type(text: "8079", elementId: "PortField")
        tapButton(title: "Done", in: UINavigationBar.self)
    }

    func setCrashOnLoginSwitch(switchState: Bool) {
        DTLog(.sessionReplay, "=============********===================")
        DTLog(.sessionReplay, "SET CRASH ON LOGIN")
        DTLog(.sessionReplay, "=============********===================")
        tapButton(buttonId: "Settings Button", in: UINavigationBar.self)

        let button = EarlGrey.selectElement(with: grey_accessibilityID("crashOnLoginSwitch"))
        button.perform(grey_turnSwitchOn(switchState))

        tapButton(title: "Done", in: UINavigationBar.self)
    }

    func crashHostStage() {
        DTLog(.sessionReplay, "=============********===================")
        DTLog(.sessionReplay, "CRASH HOST STAGE")
        DTLog(.sessionReplay, "=============********===================")
        tapButton(buttonId: "Settings Button", in: UINavigationBar.self)
        DispatchQueue.global().asyncAfter(deadline: .now() + 3) {
            fatalError()
        }
        type(text: "easytravel.lab.dynatrace.org", elementId: "LocalhostField")
        tapButton(title: "Done", in: UINavigationBar.self)
    }

    func loginStage() {
        loginStage("maria", "maria")
    }

    func loginStage(_ userName: String, _ password: String) {
        DTLog(.sessionReplay, "=============********===================")
        DTLog(.sessionReplay, "LOGIN STAGE")
        DTLog(.sessionReplay, "=============********===================")

        let cell = EarlGrey.selectElement(with: grey_text("User Account"))
        cell.perform(grey_tap())

        type(text: userName, elementId: "UsernameField data-dtrum-mask")
        type(text: password, elementId: "PasswordField data-dtrum-mask")
        tapButton(buttonId: "LoginButton", in: UIView.self)
        tapButton(title: "easyTravel", in: UINavigationBar.self)
    }

    func bookJourneyStage(_ destination: String = "Paris") {
        DTLog(.sessionReplay, "=============********===================")
        DTLog(.sessionReplay, "BOOK JOURNEY STAGE")
        DTLog(.sessionReplay, "=============********===================")
        selectRow(1)
        type(text: destination, in: UISearchBar.self)
        tapButton(buttonId: "Search", in: UIView.self)

        let cell = EarlGrey.selectElement(with: grey_anyOf([grey_text("Paris - City of love"), grey_text("Palm - Paris")])).atIndex(0)
        cell.perform(grey_tap())
        tapButton(title: "Book Journey", in: UIView.self)
        tapButton(title: "Search", in: UINavigationBar.self)
        tapButton(title: "Cancel", in: UISearchBar.self)
        tapButton(title: "easyTravel", in: UINavigationBar.self)
    }

    func contactStage() {
        DTLog(.sessionReplay, "=============********===================")
        DTLog(.sessionReplay, "CONTACT STAGE")
        DTLog(.sessionReplay, "=============********===================")
        selectRow(3)
        scrollWebView(WKWebView.self)
        tapButton(title: "easyTravel", in: UINavigationBar.self)
    }

    func checkTermsOfUseStage() {
        DTLog(.sessionReplay, "=============********===================")
        DTLog(.sessionReplay, "TERMS OF USE STAGE")
        DTLog(.sessionReplay, "=============********===================")
        selectRow(4)
        scrollWebView(WKWebView.self)
        tapButton(title: "easyTravel", in: UINavigationBar.self)
    }

    func fakeCrashStage() {
        DTLog(.sessionReplay, "=============********===================")
        DTLog(.sessionReplay, "SIMULATE CRASH STAGE")
        DTLog(.sessionReplay, "=============********===================")

        if let currentSession = AgentManager.sharedInstance.currentSessionDataSource?.getCurrentSession() {
            postNewSessionNotification(newSessionId: currentSession.visitId.sessionId + 1)
            postCrashesCrashedSession(currentSession.visitId)
            AgentManager.uploadData()
            wait(for: 3)
        } else {
            DTLog(.sessionReplay, "Cannot get current sessionId from tracker")
        }
    }
}

// MARK - EarlGrey Utils

extension EarlGreySessionSimulation {

    private func postNewSessionNotification(newSessionId: Int) {
        let userInfo = [
            configurationKey: [appConfigKey: [replayConfigKey: [captureKey: true]]],
            privacyOptionsKey: [crashReplayOptedInKey: true, crashReportingOptedInKey: true],
            sessionKey: [sessionIdJSONKey: newSessionId, visitorIdJSONKey: 176210205, sessionSequenceJSONKey: 0, serverIdJSONKey: 1]
        ]
        let notification = Notification(name: Notification.Name(rawValue: newSessionNotificationName),
                                        object: nil,
                                        userInfo: userInfo)
        NotificationCenter.default.post(notification)
    }

    private func postCrashesCrashedSession(_ visitId: VisitId) {
        let crashesNotification = Notification(name: NSNotification.Name(crashEventsNotificationName),
                                               object: nil,
                                               userInfo: ["crashes": [[visitorIdJSONKey: Int(visitId.visitorId) ?? -1,
                                                                       sessionIdJSONKey: visitId.sessionId,
                                                                       sessionSequenceJSONKey: visitId.sessionSeq,
                                                                       startTimeJSONKey: "2323245"]]])
        NotificationCenter.default.post(crashesNotification)
    }

    private func selectRow(_ index: UInt) {
        let cell = EarlGrey.selectElement(with: grey_kindOfClass(UITableViewCell.self)).atIndex(index)
        cell.perform(grey_tap())
    }

    private func type(text: String, elementId: String) {
        let textField = EarlGrey.selectElement(with: grey_accessibilityID(elementId))
        textField.perform(grey_clearText())
        textField.perform(grey_typeText(text))
    }

    private func type(text: String, in viewClass: AnyClass) {
        let textElement = EarlGrey.selectElement(with: grey_kindOfClass(viewClass)).atIndex(0)
        textElement.perform(grey_tap())

        var typedText = ""
        for scalar in text.unicodeScalars {
            typedText += scalar.escaped(asASCII: false)

            if !scalar.isASCII {
                textElement.perform(grey_replaceText(typedText))
                continue
            }

            textElement.perform(grey_typeText(scalar.escaped(asASCII: false)))
        }
    }

    private func tapButton(buttonId: String, in viewClass: AnyClass, optional: Bool = false) {
        var error: NSError?
        let button = EarlGrey.selectElement(with: grey_accessibilityID(buttonId)).inRoot(grey_kindOfClass(viewClass))
        button.perform(grey_tap(), error: &error)

        if let _ = error, !optional {
            XCTFail("Button not found")
        }
    }

    private func tapButton(title: String, in viewClass: AnyClass) {
        let button = EarlGrey.selectElement(with: grey_buttonTitle(title)).inRoot(grey_kindOfClass(viewClass))
        button.perform(grey_tap())
    }

    private func scrollWebView(_ webViewClass: AnyClass) {
        let webView = EarlGrey.selectElement(with: grey_kindOfClass(webViewClass))
        webView.perform(grey_swipeSlowInDirection(GREYDirection.up))
        webView.perform(grey_swipeSlowInDirection(GREYDirection.up))
        webView.perform(grey_swipeSlowInDirection(GREYDirection.up))
    }

}
