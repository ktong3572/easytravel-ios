import XCTest

extension XCTestCase {

    func wait(for timeInterval: TimeInterval) {
        let startTime = Date.timeIntervalSinceReferenceDate
        let startDate = Date()
        let timeout = timeInterval + 1

        while !(Date.timeIntervalSinceReferenceDate - startTime >= timeInterval) &&
            startDate.timeIntervalSinceNow < timeout {
            CFRunLoopRunInMode(CFRunLoopMode.defaultMode, 0.5, false)
        }
    }

}
