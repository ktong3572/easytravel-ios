//
//  ViewController.swift
//  easyTravel tvOS
//
//  Created by Marcel Breitenfellner on 16.07.21.
//  Copyright © 2021 Dynatrace. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

