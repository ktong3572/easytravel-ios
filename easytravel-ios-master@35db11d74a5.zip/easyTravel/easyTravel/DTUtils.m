//
//  DTUtils.m
//  easyTravel
//
//  Created by Patrick Haruksteiner on 2011-12-28.
//  Copyright (c) 2011 dynaTrace software. All rights reserved.
//

#import "DTUtils.h"

#import <Dynatrace/Framework.h>
#import "easyTravel-Swift.h"

@implementation DTUtils

+ (long long)secondsForTimeInterval:(NSTimeInterval)timeInterval
{
    return (long long)(timeInterval *1000);
}

+ (void)showErrorMessage:(NSString*)errorMessage
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                        message:errorMessage
                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
    [alertView show];
}

+ (NSDate*)dateFromString:(NSString*)dateString withFormat:(NSString*)format
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = format;
    NSDate *dateFromString = [dateFormatter dateFromString:dateString];
    return dateFromString;
}

+ (NSString*)stringFromDate:(NSDate*)date withFormat:(NSString*)format
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = format;
    return [dateFormatter stringFromDate:date];
}

static UIImage *sharedMissingImage = nil;   //display for PHAImage if no image is found (only alloc once)
+ (UIImage *)missingImage{
    if(sharedMissingImage == nil){
        sharedMissingImage = [[UIImage alloc] initWithContentsOfFile:[NSString stringWithFormat:@"%@/%@",[[NSBundle mainBundle] resourcePath], @"missingimage.png"]];   //only allocate once
    }
    return sharedMissingImage;
}

+ (NSString*)uemServerName
{
    NSUserDefaults* userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *alternativMonitorSignalDestination = [userDefaults valueForKey: SettingsController.ADK_MONITOR_SIGNAL_DESTINATION];
    if([alternativMonitorSignalDestination length] > 0){ //special monitor signal target
        if([alternativMonitorSignalDestination hasPrefix:@"http"]){
            return alternativMonitorSignalDestination;
        }
        return [NSString stringWithFormat:@"http://%@", alternativMonitorSignalDestination];
    }
    
    return [NSString stringWithFormat:@"%@:%@",
            [DTRestUtils getEasyTravelHost],
            [DTRestUtils getEasyTravelPort]];
    
}

+ (NSString*)appName
{
    return @"easyTravel mobile";
}

#pragma mark -
#pragma mark global values for this app

static NSString *_userName = nil;

+ (NSString*)userName
{
    return _userName;
}

+ (void)setUserName:(NSString*)userName
{
    _userName = userName;
}

#pragma mark -
#pragma mark swift helper functions

@end
