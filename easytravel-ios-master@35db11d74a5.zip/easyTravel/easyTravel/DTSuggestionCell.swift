final class DTSuggestionCell: UITableViewCell {

    private var label: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let margin = CGFloat(15)

    var suggestion: String? {
        get { label.text }
        set { label.text = newValue }
    }

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    
    private func setup() {
        setupView()
        setupConstraints()
    }

    private func setupView() {
        addSubview(label)
    }

    private func setupConstraints() {
        NSLayoutConstraint.activate([
            label.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: margin),
            label.trailingAnchor.constraint(lessThanOrEqualTo: self.trailingAnchor, constant: -margin),
            label.centerYAnchor.constraint(equalTo: self.centerYAnchor)
        ])
    }
}
