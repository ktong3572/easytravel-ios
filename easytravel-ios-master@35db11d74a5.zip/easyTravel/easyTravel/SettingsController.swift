//
//  SettingsController.swift
//  easyTravel
//
//  Created by Nassar, Mohamed on 28.08.18.
//  Copyright © 2018 Dynatrace. All rights reserved.
//

import Foundation

class SettingsController:NSObject
{
    //
    // MARK:- Constants
    //
    static let userDefaults = UserDefaults.standard //define this here in case we wanna change it later
    
    //MARK:- Keys
    @objc static let EASYTRAVEL_HOST = "easyTravelHost"
    @objc static let EASYTRAVEL_PORT = "easyTravelServicePort"
    
    @objc static let APPMON_STARTUP_PATH = "appMonStartupPath"
    @objc static let DYNATRACE_APPLICATION_ID = "dynatraceApplicationID"
    @objc static let DYNATRACE_BEACON_URL = "dynatraceBeaconURL"
    @objc static let CHOSEN_PRODUCT_TYPE = "chosenProduct"
    
    @objc static let ADK_MONITOR_SIGNAL_DESTINATION = "adkMonitorSignalDestination"
    @objc static let REMEMBER_USER = "rememberUser"
    @objc static let CRASH_ON_LOGIN = "crashOnLogin"
    @objc static let CRASH_ON_SEARCH = "crashOnSearch"
    @objc static let ERRORS_ON_SEARCH_AND_BOOKING = "errorsOnSearchAndBooking"
    @objc static let FRONTEND_NOT_REACHABLE = "frontendNotReachable"
    @objc static let FIRST_LAUNCH = "firstLaunch"
    
    //MARK:- Default values
    static let DEFAULT_EASYTRAVEL_FRONTEND_HOST = "http://easytravel.lab.dynatrace.org"
    static let DEFAULT_EASYTRAVEL_FRONTEND_HTTP_PORT = "80"
    static let DEFAULT_EASYTRAVEL_FRONTEND_HTTPS_PORT = "443"
    
    static let REMEMBER_USER_DEFAULT = false
    static let CRASH_ON_LOGIN_DEFAULT = false
    static let CRASH_ON_SEARCH_DEFAULT = false
    static let ERRORS_ON_SEARCH_AND_BOOKING_DEFAULT = false
    static let FRONTEND_NOT_REACHABLE_DEFAULT = false
    
    static let DEFAULT_DYNATRACE_APPLICATION_ID = "752c288d-5973-4c79-b7d1-3a49d4d42ea0"
    static let DEFAULT_DYNATRACE_ENVIRONMENT_ID = "bf04217tce"

    static let DEFAULT_DYNATRACE_BEACON_URL = "https://bf04217tce.bf-dev.dynatracelabs.com/mbeacon"

    //
    // MARK:- Methods
    //
    static func setupFallbackUserDefaults()
    {
        let appDefaults = [
            EASYTRAVEL_HOST: DEFAULT_EASYTRAVEL_FRONTEND_HOST,
            EASYTRAVEL_PORT: DEFAULT_EASYTRAVEL_FRONTEND_HTTP_PORT,
            
            DYNATRACE_BEACON_URL: DEFAULT_DYNATRACE_BEACON_URL,
            DYNATRACE_APPLICATION_ID: DEFAULT_DYNATRACE_APPLICATION_ID,
            
            REMEMBER_USER: REMEMBER_USER_DEFAULT,
            CRASH_ON_LOGIN: CRASH_ON_LOGIN_DEFAULT,
            CRASH_ON_SEARCH: CRASH_ON_SEARCH_DEFAULT,
            ERRORS_ON_SEARCH_AND_BOOKING: ERRORS_ON_SEARCH_AND_BOOKING_DEFAULT,
            FRONTEND_NOT_REACHABLE: FRONTEND_NOT_REACHABLE_DEFAULT,
            FIRST_LAUNCH: true,
            ADK_MONITOR_SIGNAL_DESTINATION: ""
        ] as [String:Any]
        
        userDefaults.register(defaults: appDefaults)
        self.setDoneWithFirstLaunch()
    }
    
    //
    // MARK:- Getters
    //
    
    @objc static func isFirstLaunch() -> Bool
    {
        return userDefaults.bool(forKey: FIRST_LAUNCH)
    }
    
    @objc static func getEasyTravelHost() -> String
    {
        if let host = userDefaults.value(forKey: EASYTRAVEL_HOST) as? String
        {
            if host.hasPrefix("http")
            {
                return host
            }
            else
            {
                return "http://" + host
            }
        }
        else
        {
            return DEFAULT_EASYTRAVEL_FRONTEND_HOST
        }
    }
    
    @objc static func getEasyTravelPort() -> String
    {
        if let port = userDefaults.value(forKey: EASYTRAVEL_PORT) as? String
        {
            return port
        }
        else
        {
            let host = SettingsController.getEasyTravelHost()
            if host.hasPrefix("https")
            {
                return DEFAULT_EASYTRAVEL_FRONTEND_HTTPS_PORT
            }
            else
            {
                return DEFAULT_EASYTRAVEL_FRONTEND_HTTP_PORT
            }
        }
    }
    
    static func getDTBeaconURL() -> String
    {
        if let beaconURL = userDefaults.string(forKey: DYNATRACE_BEACON_URL)
        {
            return beaconURL
        }
        else
        {
            return DEFAULT_DYNATRACE_BEACON_URL
        }
    }
    
    static func getDTAppID() -> String
    {
        if let appID = userDefaults.string(forKey: DYNATRACE_APPLICATION_ID)
        {
            return appID
        }
        else
        {
            return DEFAULT_DYNATRACE_APPLICATION_ID
        }
    }
    
    static func getAlternativMonitorSignalDestination() -> String?
    {
        return userDefaults.object(forKey: ADK_MONITOR_SIGNAL_DESTINATION) as? String
    }
    
    static func getCrashOnLoginValue() -> Bool
    {
        return userDefaults.bool(forKey: CRASH_ON_LOGIN)
    }
    
    static func getCrashOnSearchValue() -> Bool
    {
        return userDefaults.bool(forKey: CRASH_ON_SEARCH)
    }

    static func getFrontEndNotReachableValue() -> Bool
    {
        return userDefaults.bool(forKey: FRONTEND_NOT_REACHABLE)
    }
    
    static func getErrorOnSearchAndBookingValue() -> Bool
    {
        return userDefaults.bool(forKey: ERRORS_ON_SEARCH_AND_BOOKING)
    }
    
    //
    // MARK:- Setters
    //
    static func setHost(_ host:String)
    {
        if host.count > 3 //Shortest hostname is s.t. like 1.at
        {
            userDefaults.set(host, forKey: EASYTRAVEL_HOST)
        }
    }
    
    static func setPort(_ port:String)
    {
        if Int(port) != nil, Int(port)! > 0 && Int(port)! < 65536 //no strings, only valid port ranges 0 - (2^16)-1
        {
            userDefaults.set(port, forKey: EASYTRAVEL_PORT)
        }
        else
        {
            userDefaults.removeObject(forKey: EASYTRAVEL_PORT)
        }
    }
    
    static func setAppMonPath(_ path: String)
    {
        if path.hasPrefix("http")
        {
            userDefaults.set(path, forKey: APPMON_STARTUP_PATH)
        }
    }
    
    static func setDTBeaconURL(_ beaconURL: String)
    {
        if beaconURL.hasPrefix("http")
        {
            userDefaults.set(beaconURL, forKey: DYNATRACE_BEACON_URL)
        }
    }
    
    static func setDTAppID(_ newAppID: String)
    {
        userDefaults.set(newAppID, forKey: DYNATRACE_APPLICATION_ID)
    }
    
    static func setAlternativMonitorSignalDestination(_ altDestination: String)
    {
        if altDestination.count > 3
        {
            userDefaults.set(altDestination, forKey: ADK_MONITOR_SIGNAL_DESTINATION)
        }
        else
        {
            userDefaults.set("", forKey: ADK_MONITOR_SIGNAL_DESTINATION)
        }
    }
    
    static func setCrashOnLoginValue(_ crashOnLogin:Bool)
    {
        userDefaults.set(crashOnLogin, forKey: CRASH_ON_LOGIN)
    }
    
    static func setCrashOnSearchValue(_ crashOnSearch:Bool)
    {
        userDefaults.set(crashOnSearch, forKey: CRASH_ON_SEARCH)
    }

    static func setFrontendNotReachable(_ frontEndNotReachable: Bool)
    {
        userDefaults.set(frontEndNotReachable, forKey: FRONTEND_NOT_REACHABLE)
    }
    
    static func setErrorsOnSearchAndBooking(_ errors: Bool)
    {
        userDefaults.set(errors, forKey: ERRORS_ON_SEARCH_AND_BOOKING)
    }
    
    static func setDoneWithFirstLaunch()
    {
        userDefaults.set(false, forKey: FIRST_LAUNCH)
    }
    
    static func getDynatraceConfigDictionary() -> [String: Any?]
    {
        //Create a new startup dictionary
        let dynatraceConfigDictionary = [
            kDTXApplicationID: SettingsController.getDTAppID(),
            kDTXBeaconURL: SettingsController.getDTBeaconURL(),
            kDTXAllowAnyCert: true,
            kDTXAgentCertificatePath: nil,
            kDTXLogLevel: "ALL",
            kDTXUserOptIn: true,
            "DTXLoadbalancingV2": true
            ] as [String : Any?]

        print(dynatraceConfigDictionary)
        return dynatraceConfigDictionary
    }
}
