//
//  DTLoginViewController.swift
//  easyTravel
//
//  Created by Marcel Breitenfellner on 17.07.17.
//  Copyright © 2017 Dynatrace. All rights reserved.
//

import UIKit
import Security

class DTLoginViewController: UIViewController, DTResultHandler {
    
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var loginActivityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var loginLabel: UILabel!
    @IBOutlet weak var rememberUserSwitch: UISwitch!
    
    var loginResult : NSMutableDictionary?
    var currentLoginElement : String?
    var loginAction : DTXAction?
    var loginAnimationAction : DTXAction?
    var closeOnSuccess = false
    
    static var sharedKeychain : KeychainItemWrapper?
    class func sharedKeychainWrapper() -> KeychainItemWrapper{
        if sharedKeychain == nil {
            sharedKeychain = KeychainItemWrapper(identifier: DTConstants.kKeychainIdentifier, accessGroup: nil)
        }
        return sharedKeychain!
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setNavigationBarColor(UIColor.easyTravelOrange, withTextColor: UIColor.white)
        
        loginLabel.isHidden = true
        
        rememberUserSwitch.setOn(UserDefaults.standard.bool(forKey: SettingsController.REMEMBER_USER), animated: false)
        loadKeychainData()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        UserDefaults.standard.set(rememberUserSwitch.isOn, forKey: SettingsController.REMEMBER_USER)
        updateKeychainData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func loadKeychainData() {
        if UserDefaults.standard.bool(forKey: SettingsController.REMEMBER_USER) {
            let keyChainUser = DTLoginViewController.sharedKeychainWrapper().object(forKey: kSecAttrAccount)
            let KeyChainPassword = DTLoginViewController.sharedKeychainWrapper().object(forKey: kSecValueData)
            
            if let user = keyChainUser as? String, let pw = KeyChainPassword as? String {
                username.text = user
                password.text = pw
            }
        }
    }
    
    func updateKeychainData() {
        if UserDefaults.standard.bool(forKey: SettingsController.REMEMBER_USER) {
            // update data
            let keyChain = DTLoginViewController.sharedKeychainWrapper()
            keyChain.setObject(username.text, forKey: kSecAttrAccount)
            keyChain.setObject(password.text, forKey: kSecValueData)
        } else {
            // clear data
            DTLoginViewController.sharedKeychainWrapper().resetKeychainItem()
        }
    }
    
    @IBAction func loginButtonTouchUp(_ sender: Any) {
        if let userName = username.text {
            Dynatrace.identifyUser(userName)
            setCrashPatternForUserName(username.text)
        }

        Dynatrace.modifyUserAction( { (action) -> () in
            action?.setName("login button pressed (custom user action name demo)")
            action?.reportValue(withName: "Dynatrace.modifyUserAction", stringValue: "hello wörld")
        })
        
        if UserDefaults.standard.bool(forKey: SettingsController.CRASH_ON_LOGIN) {
            let crashAlertController = UIAlertController(title: "CRASH", message: "You just triggered a crash!", preferredStyle: .alert)
            crashAlertController.addAction(UIAlertAction(title: "OK", style: .destructive) { _ in
                crashAlertController.dismiss(animated: false)

                // provoke a crash
                fatalError()
            })

            self.present(crashAlertController, animated: true, completion: nil)
        }
        
        username.resignFirstResponder()
        password.resignFirstResponder()
        
        if checkLoginStringValidity(username.text, message: "Username is empty!")
            && checkLoginStringValidity(password.text, message: "Password is empty!") {
            performLogin()
        }
        
    }
    
    func checkLoginStringValidity(_ loginString : String?, message: String) -> Bool {
        if let str = loginString,
            str.count <= 0 {
            loginLabel.text = message
            loginLabel.textColor = UIColor.red
            loginLabel.isHidden = false
            return false
        }
        return true
    }
    
    func performLogin() {
        loginAction = DTXAction.enter(withName: DTConstants.LOGIN_ACTION)
        loginAnimationAction = DTXAction.enter(withName: DTConstants.LOGIN_ANIMATION_ACTION, parentAction: loginAction)
        
        loginActivityIndicator.startAnimating()
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        
        var params = Dictionary<String, String>()
        params["userName"] = username.text
        params["password"] = password.text

        DTRestUtils(delegate: self, showErrors: true).performOperation(AUTHENTICATE, ofService: AUTH_SERVICE, withParameters: params, withKey: username.text)
        
        // 3rd party stuff - not instrumented backend
        let timeout = 2.0
        loadURL("https://plus.google.com/+dynatrace", withTimeout: timeout)
        loadURL("https://www.facebook.com/Dynatrace/", withTimeout: timeout)
    }
    
    func loadURL(_ urlStr : String, withTimeout timeout : Double) {
        if let url = URL(string: urlStr) {
            let request = URLRequest(url: url, cachePolicy: .useProtocolCachePolicy, timeoutInterval: timeout)
            let task = URLSession.shared.dataTask(with: request)
            task.resume()
        }
    }
    
    func cleanup() {
        loginActivityIndicator.stopAnimating()
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
        loginAction?.leave()
        loginAction = nil
        loginAnimationAction?.leave()
        loginAnimationAction = nil
    }
    
    // DTHandler delegate methods
    func operationFinished(_ data: NSObject!) {
        //check if we got correct data - else do not overwrite messages set by operatioFailed:
        if let result = data as? NSDictionary {
            let value = result.object(forKey: kAuthentictionResponse)
            if let strValue = result.object(forKey: String(format: DTConstants.kReturn)) as? NSString,
                value != nil {
                loginFinished(successful: strValue.boolValue)
            } else {
                loginFinished(successful: false)
            }
        }
        
        //close action after reporting values
        cleanup()
    }
    
    func loginFinished(successful : Bool) {
        if successful {
            loginAction?.reportValue(withName: DTConstants.LOGIN_SUCCESSFUL, stringValue: username.text ?? "")
            DTUtils.setUserName(username.text)
            if closeOnSuccess {
                // came from journey view -> go back if logged in
                navigationController?.popViewController(animated: true)
            } else {
                loginLabel.text = "Login successful!"
                loginLabel.textColor = UIColor.green
                loginLabel.isHidden = false
            }
        } else {
            DTUtils.setUserName(nil)
            loginAction?.reportEvent(withName: DTConstants.LOGIN_FAILED)
            loginLabel.text = "Login failed!"
            loginLabel.textColor = UIColor.red
            loginLabel.isHidden = false
        }
    }
    
    func operationFailed(_ data: NSObject!) {
        cleanup()
        loginFinished(successful: false)
    }
    
    func parseXMLResponse(_ xmlData: Data!) -> [AnyHashable : Any]! {
        let parser = XMLParser(data: xmlData)
        parser.delegate = self
        loginResult = NSMutableDictionary()
        
        if parser.parse() {
            return loginResult as! [AnyHashable : Any]
        }
        return nil
    }
    
    // NSXMLParser delegate methods
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        NSLog("START element: \(elementName) nsURI: \(namespaceURI ?? "") qname: \(qName ?? "") attributes: \(attributeDict)")
        DTRestUtils.parseNamespacePrefix(attributeDict)
        currentLoginElement = elementName
        if let curLoginElement = currentLoginElement {
            // insert element key
            loginResult?.setObject(NSNull(), forKey: curLoginElement as NSCopying)
        }
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        NSLog("ELEMENT content: \(string)")
        if string.count > 0,
            let curLoginElement = currentLoginElement {
            // replace value for element if present
            loginResult?.setObject(string, forKey: curLoginElement as NSCopying)
        }
    }
    
    func parser(_ parser: XMLParser, parseErrorOccurred parseError: Error) {
        loginAction?.reportError(withName: DTConstants.LOGIN_ERROR, error: parseError)
        NSLog("\(parseError.localizedDescription)")
    }

    private func setCrashPatternForUserName(_ userName: String?) {
        switch userName {
        case "greta", "silvia":
            SettingsController.setCrashOnSearchValue(true)
        case "monica":
            SettingsController.setCrashOnLoginValue(true)
        default:
            return
        }
    }

}
