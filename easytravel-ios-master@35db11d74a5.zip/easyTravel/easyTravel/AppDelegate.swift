//
//  AppDelegate.swift
//  testapp
//
//  Created by Marcel Breitenfellner on 17.07.17.
//  Copyright © 2017 Dynatrace. All rights reserved.
//

import UIKit
import CoreLocation
import Dynatrace
import DynatraceSessionReplay

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, CLLocationManagerDelegate {
    
    var window: UIWindow?
    var locationManager: CLLocationManager?
    @objc dynamic var isRecording = false
    private var testHandler = DTTestHandler()
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        subscribeToOneAgentNotifications()
        let startDate = Date()

        #if SESSION_REPLAY_TESTS
        Dynatrace.startupWithInfoPlistSettings()
        #else
        let startupDictionary = SettingsController.getDynatraceConfigDictionary()
        Dynatrace.startup(withConfig: startupDictionary)

        //for cookie testing purpose - multi-cookies
        let beaconHeaders = [
            "App":"easyTravel mobile",
            "Platform":"iOS",
            "Vendor":"Dynatrace"
        ]
        Dynatrace.setBeaconHeaders(beaconHeaders)
        SettingsController.setupFallbackUserDefaults()

        //Dynatrace.startup(withApplicationName: DTUtils.appName(), serverURL: DTUtils.uemServerName(), allowAnyCert: true, certificatePath: nil)
        
        let crashreportingStatus = Dynatrace.enableCrashReporting(withReport: true)
        if crashreportingStatus != DTX_StatusCode.crashReportingAvailable {
            DTXAction.reportError(withName: "Failed to enable crash reporting", errorValue: crashreportingStatus.rawValue)
        }
        #endif

        setMaskingConfiguration()
        resetCrashPatternsToDefaults()

        let timeSinceLaunch = startDate.timeIntervalSince(Date())
        if timeSinceLaunch < 0.5 {
            //ensure that splash is shown even on fast devices for at least 0.5 sec
            Thread.sleep(forTimeInterval: timeSinceLaunch)
        }
        
        locationManager = CLLocationManager()
        locationManager?.delegate = self
        locationManager?.desiredAccuracy = kCLLocationAccuracyThreeKilometers
        locationManager?.startUpdatingLocation()
        
        window?.makeKeyAndVisible()
        
        testHandler.handleTestIfNeeded(window)
        return true
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
        locationManager?.stopUpdatingLocation()
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .none
        
        //for cookie testing purpose - single-cookies
        let beaconHeaders = [
            "App":"easyTravel mobile",
            "Platform":"iOS",
            "Vendor":"Dynatrace"
        ]
        Dynatrace.setBeaconHeaders(beaconHeaders)
        locationManager?.stopUpdatingLocation()
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        locationManager?.startUpdatingLocation()
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        self.confirmPrivacySettingsAndStartAgent {
            if SettingsController.isFirstLaunch()
            {
                if let mainStoryBoardName = Bundle.main.object(forInfoDictionaryKey: "UIMainStoryboardFile") as? String, let settingsViewController = UIStoryboard(name: mainStoryBoardName, bundle: Bundle.main).instantiateViewController(withIdentifier: "SettingsNavigationController") as? UINavigationController
                {
                    self.window?.rootViewController?.present(settingsViewController, animated: true, completion: nil)
                }
            }
        }
        
        locationManager?.startUpdatingLocation()
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        locationManager?.stopUpdatingLocation()
    }
 
    //
    //MARK:- Privacy and GDPR
    //
    func confirmPrivacySettingsAndStartAgent(completion: @escaping () -> Void) {
        if !PrivacyManager.didDisplayPrivacyDialog { //We have not asked the user before, let us ask them
            PrivacyManager.getUserConsent(presentingViewController: window?.rootViewController) {
                completion()
            }
        }
    }
    
    //
    // MARK:- CLLocationManagerDelegate methods
    //
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        Dynatrace.setGpsLocation(locations[0])
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        DTXAction.reportError(withName: "CLLocationManager didFailWithError:", error: error)
    }

    private func resetCrashPatternsToDefaults() {
        SettingsController.setCrashOnLoginValue(SettingsController.CRASH_ON_LOGIN_DEFAULT)
        SettingsController.setCrashOnSearchValue(SettingsController.CRASH_ON_SEARCH_DEFAULT)
    }


    private func subscribeToOneAgentNotifications() {
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(handleOneAgentNotification),
                                               name: NSNotification.Name("DTXNewSessionNotification"),
                                               object: nil)

        NotificationCenter.default.addObserver(self,
                                               selector: #selector(handleOneAgentNotification),
                                               name: NSNotification.Name("DTXServerConfigurationChangedNotification"),
                                               object: nil)
    }

    private func setMaskingConfiguration() {
        let maskingConfiguration = MaskingConfiguration(maskingLevelType: .custom)
        try? maskingConfiguration.removeAllRules()
        try? maskingConfiguration.add(rule: .maskAllInputFields)
        try? maskingConfiguration.addNonMaskedView(viewIds: ["SearchBar", "UISearchBarTextField"])
        try? AgentManager.setMaskingConfiguration(maskingConfiguration)
    }

    @objc func handleOneAgentNotification(notification: NSNotification) {
        if let configuration = notification.userInfo?["configuration"] as? NSDictionary,
           let appConfig = configuration["appConfig"] as? NSDictionary,
           let replayConfig = appConfig["replayConfig"] as? NSDictionary,
           let isRumCaptureEnabled = appConfig["capture"] as? Bool,
           let isReplayCaptureEnabled = replayConfig["capture"] as? Bool,
           let privacyOptions = notification.userInfo?["privacyOptions"] as? NSDictionary,
           let crashReplayOptedIn = privacyOptions["crashReplayOptedIn"] as? Bool {
            isRecording = isRumCaptureEnabled && isReplayCaptureEnabled && crashReplayOptedIn
        }
    }
}


