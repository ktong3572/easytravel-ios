//
//  SplitViewController.swift
//  easyTravel
//
//  Created by Marcel Breitenfellner on 15.01.21.
//  Copyright © 2021 Dynatrace. All rights reserved.
//

import UIKit

class SplitViewController: UISplitViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        preferredDisplayMode = .allVisible
    }
}
