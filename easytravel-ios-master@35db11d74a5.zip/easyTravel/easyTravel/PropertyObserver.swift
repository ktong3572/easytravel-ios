import Foundation

class PropertyObserver: NSObject {
    let completionHandler: ((Bool) -> Void)?

    init(onCompletionHandler completionHandler: ((Bool) -> Void)?) {
        self.completionHandler = completionHandler
    }

    override public func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        guard let change = change else { return }

        let isRecording = change[NSKeyValueChangeKey.newKey] as? Bool ?? false
        completionHandler?(isRecording)
    }
}
