//
//  UIViewController+setNavigationBarColor.swift
//  easyTravel
//
//  Created by Marcel Breitenfellner on 13.07.21.
//  Copyright © 2021 Dynatrace. All rights reserved.
//

import UIKit

extension UIViewController {
    func setNavigationBarColor(_ barTintColor : UIColor, withTextColor textColor : UIColor) {
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: textColor]
        
        if #available(iOS 13.0, *)
        {
            let appearance = UINavigationBarAppearance()
            appearance.configureWithOpaqueBackground()
            appearance.backgroundColor = barTintColor
            navigationController?.navigationBar.standardAppearance = appearance
            navigationController?.navigationBar.scrollEdgeAppearance = appearance
        } else {
            navigationController?.navigationBar.barTintColor = barTintColor
        }
    }
}
