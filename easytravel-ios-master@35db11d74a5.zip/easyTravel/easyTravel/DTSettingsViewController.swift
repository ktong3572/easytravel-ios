//
//  DTSettingsViewControllerSW.swift
//  easyTravel
//
//  Created by labuser on 11.07.17.
//  Copyright © 2017 Dynatrace. All rights reserved.
//

import UIKit
import Toast_Swift

class DTSettingsViewController: UITableViewController {
    
    //
    // MARK:- Variables IBOutlets
    //
    @IBOutlet weak var easyTravelHost: UITextField!
    @IBOutlet weak var easyTravelPort: UITextField!
    @IBOutlet weak var agentInfoLabel: UILabel!
    @IBOutlet weak var crashOnLoginSwitch: UISwitch!
    @IBOutlet weak var frontendNotReachableSwitch: UISwitch!
    @IBOutlet weak var errorsOnSearchAndBooking: UISwitch!
    @IBOutlet weak var doneButton: UIBarButtonItem!
    @IBOutlet weak var dynatraceBeaconURLTextfield: UITextField!
    @IBOutlet var dynatraceAppIDTextField: UITextField!

    var layoutTopConstraint : NSLayoutConstraint?
    let agentShutdownNotificationName = NSNotification.Name(rawValue: "DTXAgentShutdownCompletedNotification")
    var monitoringSettingsChanged = false
    
    //
    // MARK:- View lifecycle
    //
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setNavigationBarColor(UIColor.easyTravelOrange, withTextColor: UIColor.white)
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .short
        dateFormatter.timeStyle = .short
        agentInfoLabel.text = String(format: "easyTravel: %@, OneAgent: %@", Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as! String, Dynatrace.agentVersionString())
        crashOnLoginSwitch.accessibilityIdentifier = "crashOnLoginSwitch"
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        loadSettings()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        super.viewWillDisappear(animated)
        
        // cleanup
        NotificationCenter.default.removeObserver(self)
        
        self.easyTravelPort.resignFirstResponder()
        self.easyTravelHost.resignFirstResponder()
    }
    
    /**
     This method starts the agent restart process and adds a notification handler for DTXAgentShutdownCompletedNotification. Then the agent is actually started again in agentDidShutDown()
     */
    @objc func restartAgent()
    {
        self.view.makeToastActivity(.center)
        NotificationCenter.default.addObserver(self, selector: #selector(agentDidShutDown), name: agentShutdownNotificationName, object: nil)
        Dynatrace.shutdown()
    }
    
    @objc func agentDidShutDown()
    {
        let configDictionary = SettingsController.getDynatraceConfigDictionary()
        Dynatrace.startup(withConfig: configDictionary)
        NSLog("server name updated and DynatraceUEM restarted")
        NotificationCenter.default.removeObserver(self, name: agentShutdownNotificationName, object: nil)
        
        self.view.hideToastActivity()

        let presentingVC = self.presentingViewController
        //Dismiss this view controller
        self.dismiss(animated: true, completion: {
            presentingVC?.view.makeToast("Agent restarted with new configuration")
        })
    }
    
    private func loadSettings()
    {
        easyTravelHost.text = SettingsController.getEasyTravelHost()
        easyTravelPort.text = SettingsController.getEasyTravelPort()

        dynatraceBeaconURLTextfield.text = SettingsController.getDTBeaconURL()
        dynatraceAppIDTextField.text = SettingsController.getDTAppID()

        crashOnLoginSwitch.setOn(SettingsController.getCrashOnLoginValue(), animated: false)
        frontendNotReachableSwitch.setOn(SettingsController.getFrontEndNotReachableValue(), animated: false)
        errorsOnSearchAndBooking.setOn(SettingsController.getErrorOnSearchAndBookingValue(), animated: false)
    }
    
    private func saveSettings() {
        let easyTravelHost = self.easyTravelHost.text
        let easyTravelPort = self.easyTravelPort.text
        
        if let host = easyTravelHost {
            SettingsController.setHost(host)
        }
        
        if let port = easyTravelPort as String? {
            SettingsController.setPort(port)
        }


        if let appID = dynatraceAppIDTextField.text, appID != SettingsController.getDTAppID() {
            monitoringSettingsChanged = true
            SettingsController.setDTAppID(appID)
        }

        if let beaconURL = dynatraceBeaconURLTextfield.text, beaconURL != SettingsController.getDTBeaconURL() {
            monitoringSettingsChanged = true
            SettingsController.setDTBeaconURL(beaconURL)
        }
        
        SettingsController.setCrashOnLoginValue(crashOnLoginSwitch.isOn)
        SettingsController.setFrontendNotReachable(frontendNotReachableSwitch.isOn)
        SettingsController.setErrorsOnSearchAndBooking(errorsOnSearchAndBooking.isOn)
        SettingsController.setDoneWithFirstLaunch()
    }
    
    @IBAction func doneButtonTapped(_ sender: Any) {
        saveSettings()
        if self.monitoringSettingsChanged {
            if let agentVersion = Dynatrace.agentVersionStringNoBuild(), agentVersion >= "7.3" {
                self.restartAgent()
            } else {
                let restartAlertView = UIAlertController(title: "Monitoring Settings Changed", message: "You will need to restart the app to enable the new settings. If you choose Quit, the app will be shutdown and then you need to tap on it again to launch it.", preferredStyle: .alert)
                let restartAction = UIAlertAction(title: "Quit", style: .default, handler: { (_) in
                    exit(EXIT_SUCCESS)
                })
                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (_) in
                    self.dismiss(animated: true, completion: nil)
                }
                
                restartAlertView.addAction(restartAction)
                restartAlertView.addAction(cancelAction)
                self.present(restartAlertView, animated: true, completion: nil)
            }
        } else {
            self.dismiss(animated: true, completion: nil)
        }
        
    }
    
    // close keyboard
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        easyTravelPort.resignFirstResponder()
        easyTravelHost.resignFirstResponder()
    }

}
