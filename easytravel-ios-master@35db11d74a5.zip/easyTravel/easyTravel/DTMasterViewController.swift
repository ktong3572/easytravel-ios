//
//  DTMasterViewControllerSW.swift
//  easyTravel
//
//  Created by Marcel Breitenfellner on 17.07.17.
//  Copyright © 2017 Dynatrace. All rights reserved.
//

import UIKit

class DTMasterViewController: UITableViewController {
    
    @IBOutlet var settingsButton: UIButton?
    lazy var uiBadgeView: UIView = {
        let top = ((navigationController?.navigationBar.frame.height ?? badgeSize) - badgeSize) / 2
        let uiBadge = UIView(frame: CGRect(x: badgeSize, y: top, width: badgeSize, height: badgeSize))
        uiBadge.backgroundColor = .systemRed
        uiBadge.layer.cornerRadius = badgeSize / 2
        uiBadge.isAccessibilityElement = true
        uiBadge.accessibilityIdentifier = "Recording signal"
        return uiBadge
    }()
    let badgeSize: CGFloat = 10.0
    var isRecordingObserver: PropertyObserver?

    deinit {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.removeObserver(isRecordingObserver!, forKeyPath: #keyPath(AppDelegate.isRecording), context: nil)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        isRecordingObserver = PropertyObserver(onCompletionHandler: showRecordingSignal)

        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.addObserver(isRecordingObserver!, forKeyPath: #keyPath(AppDelegate.isRecording), options: [ .new ], context: nil)

        self.setNavigationBarColor(UIColor.easyTravelOrange, withTextColor: UIColor.white)

        //This is because starting iOS 11, Navigation bars use autolayout and they mess up the images of the buttons. So we're adding constraints.
        //However, constraints are only available starting iOS 9
        if #available(iOS 9.0, *)
        {
            settingsButton?.widthAnchor.constraint(equalToConstant: 34).isActive = true
            settingsButton?.heightAnchor.constraint(equalToConstant: 34).isActive = true
        }
        else
        {
            settingsButton?.frame = CGRect(x: 0, y: 0, width: 34, height: 34)
        }
        
        self.settingsButton?.titleLabel?.text = ""
        self.settingsButton?.setImage(#imageLiteral(resourceName: "Settings Icon").withRenderingMode(.alwaysTemplate), for: .normal)
        
        // show master view on iPad potrait
        splitViewController?.preferredDisplayMode = UISplitViewController.DisplayMode.allVisible
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        showRecordingSignal(isRecording: appDelegate.isRecording)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        showRecordingSignal(isRecording: false)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var destController : DTMasterWebViewController?
        if let nav = segue.destination as? UINavigationController {
            // iPad
            destController = nav.topViewController as? DTMasterWebViewController
        } else {
            // iPhone
            destController = segue.destination as? DTMasterWebViewController
        }
        
        // prepare target web view controller
        destController?.setNavigationBarColor(UIColor.easyTravelOrange, withTextColor: UIColor.white)

        if let segId = segue.identifier {
            let host = DTRestUtils.getEasyTravelHost()
            let port = DTRestUtils.getEasyTravelPort()
            
            switch segId {
            case "ContactSegue":
                destController?.targetUrl = URL(string: String(format: "%@:%@/%@", host!, port!, "contact-orange-mobile.jsf"))
                destController?.title = "Contact"
                
            case "TermsOfUseSegue":
                destController?.targetUrl = URL(string: String(format: "%@:%@/%@", host!, port!, "legal-orange-mobile.jsf"))
                destController?.title = "Legal"
                
            case "PrivacyPolicySegue":
                destController?.targetUrl = URL(string: String(format: "%@:%@/%@", host!, port!, "privacy-orange-mobile.jsf"))
                destController?.title = "Privacy"
                
            case "specialOffers":
                destController?.title = "Special Offers"
                
            default:
                NSLog("unhandled segue identifier: \(segue.identifier ?? "")")
            }
        }
    }

    private func showRecordingSignal(isRecording: Bool) {
        if isRecording, uiBadgeView.superview == nil {
            navigationController?.navigationBar.addSubview(uiBadgeView)
        } else {
            uiBadgeView.removeFromSuperview()
        }
    }
}

