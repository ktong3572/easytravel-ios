// Dynatrace-Private.h
//
// Copyright 2011-2016 Dynatrace LLC

@class DTXMeasurement;


@interface Dynatrace (Private)

+ (DTX_StatusCode)status;
+ (BOOL)captureStatus;
+ (NSString *)serverName;
+ (void)invalidateActiveMetricCount;
+ (BOOL)executionAllowed;
+ (NSString *)agentVersionStringNoBuild;
+ (NSString *)agentVersionString;
+ (NSDate *)agentBuildDate;
+ (void)setSynthetic;

@end


//todo:make header for dtxAction and create a customer facing DTXAction wrapper class. Naming example: DTXAction->DTXInternalAction , Wrapper->DTXAction
//the actual implementation via hidden header (this one) is sub optimal.  Categories (Private) here and () in .m File already removed.

@interface DTXAction ()
@property  DTXAction *parentAction;
@property  NSDate *referenceTimestamp;
@property  NSString *filteredName;
@property  int tagId;
@property  BOOL left;
@property  NSNumber *threadId;
@property  DTXMeasurement *measurement;
@property  NSMutableArray *webRequestIds;
@property  NSDate *lifecycleEndTime;
@property  BOOL empty;
@property  BOOL createdForLifecycle;
@property  NSMutableArray *lifecycleActions;
@property  BOOL delayTimeout;
@property  unsigned int actionGroup;
@property  NSTimeInterval delayedTimeoutInterval;

+ (NSString *)replaceBars:(NSString *)string;
+ (DTXAction *)enterLifecycleActionWithControllerName:(NSString *)controllerName parentAction:(DTXAction *)parentAction;
+ (DTXAction *)enterInternalActionWithName:(NSString *)actionName
                                 startTime:(NSDate *)startTime
                             lifecycleFlag:(BOOL)lifecycleFlag
                              delayTimeout:(BOOL)delayTimeout
                               actionGroup:(unsigned int)actionGroup;

- (DTX_StatusCode)leaveLifecycleActionWithEndTime:(NSDate *)endTime;
- (DTX_StatusCode)leaveInternalAction;
- (void)discardInternalAction;
- (int)webRequestCount;
- (void)addWebRequestId:(unsigned int)requestId;
- (BOOL)setStartTime:(NSDate *)startTime ifWrappingRequestId:(NSNumber *)requestId;
- (BOOL)setWebRequestEndTime:(NSDate *)endTime forRequestId:(NSNumber *)requestId;
- (NSDate *)getStartTime;
- (BOOL)isEmpty;
- (BOOL)hasActiveLifecycle;
- (void)addLifecycleChild:(DTXAction *)lifecycleAction;
- (void)removeLifecycleChild:(DTXAction *)lifecycleAction withEndTime:(NSDate *)endTime;
- (int)parentTagId;
- (DTXMeasurement *)actionMeasurement;
- (DTXAction *)getParentAction;
- (BOOL)isDelayedTimeout;
- (void)resetDelayedTimeout;
- (NSTimeInterval)getDelayedTimeoutInterval;
- (void)incrementDelayedTimeoutInterval:(NSTimeInterval)timeInterval;
- (NSDate*) getRealReferenceTimestamp;
- (NSArray*) getChilds;

@end
