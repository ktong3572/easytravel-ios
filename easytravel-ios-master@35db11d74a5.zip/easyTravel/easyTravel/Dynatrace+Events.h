//
//  Dynatrace+Events.h
//  DynatraceUEM
//
//  Created by Landsmann, Maximilian on 18.02.22.
//  Copyright © 2022 Dynatrace LLC. All rights reserved.
//

#ifndef Dynatrace_Events_h
#define Dynatrace_Events_h

#import <Foundation/Foundation.h>
#import <Dynatrace/Dynatrace.h>

NS_ASSUME_NONNULL_BEGIN

@interface Dynatrace (Events)

+ (void)sendEventWithName:(NSString*)name attributes:(NSDictionary<NSString*,id>* _Nullable)attributes;

@end

NS_ASSUME_NONNULL_END

#endif /* Dynatrace_Events_h */
