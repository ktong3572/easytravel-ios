//
//  DTDestination.m
//  easyTravel
//
//  Created by Patrick Haruksteiner on 2012-01-02.
//  Copyright (c) 2012 dynaTrace software. All rights reserved.
//

#import "DTLocation.h"

@implementation DTLocation

@end
