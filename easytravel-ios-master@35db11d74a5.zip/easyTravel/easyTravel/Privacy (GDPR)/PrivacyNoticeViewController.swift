//
//  PrivacyManagerViewController.swift
//  Dynatrace Mobile
//
//  Created by Nassar, Mohamed on 27.04.18.
//  Copyright © 2018 Dynatrace. All rights reserved.
//

import UIKit
import DynatraceSessionReplay

class PrivacyNoticeViewController: UIViewController
{
    //
    // MARK:- Constants
    //
    let cornerRadius:CGFloat = 5.0
    let borderWidth:CGFloat = 1.0
    
    //
    // MARK:- UIOutlets
    //
    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet var acceptButton: UIButton!
    @IBOutlet var manageSettingsButton: UIButton!
    @IBOutlet var frameView: UIView!
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        get
        {
            return .default
        }
    }
    
    //
    // MARK:- Completion block
    //
    var completionBlock: (() -> Void)?
    
    //
    // MARK:- Functions
    //
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setNeedsStatusBarAppearanceUpdate()
        
        self.frameView.layer.cornerRadius = cornerRadius
        self.frameView.layer.borderWidth = 0.1
        self.frameView.layer.borderColor = UIColor.lightGray.cgColor
        
        self.acceptButton.layer.cornerRadius = cornerRadius
        
        self.manageSettingsButton.layer.cornerRadius = cornerRadius
        self.manageSettingsButton.layer.borderColor = UIColor.systemOrange.cgColor
        self.manageSettingsButton.layer.borderWidth = borderWidth
        //prevent pull down to close
        self.modalPresentationStyle = .fullScreen
        if #available(iOS 13.0, *) {
            self.isModalInPresentation = true
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if self.traitCollection.verticalSizeClass == .compact
        {
            self.scrollView.flashScrollIndicators()
        }
    }
    
    //
    // MARK:- UI Interaction
    //
    @IBAction func acceptButtonTapped(_ sender: UIButton) {
        //store with default config
        let privacyConfig = Dynatrace.userPrivacyOptions()
        privacyConfig.dataCollectionLevel = .userBehavior
        privacyConfig.crashReportingOptedIn = true
        privacyConfig.crashReplayOptedIn = true
        let maskingConfiguration = MaskingConfiguration(maskingLevelType:.custom)
        try? maskingConfiguration.removeAllRules()
        try? AgentManager.setMaskingConfiguration(maskingConfiguration)
        Dynatrace.applyUserPrivacyOptions(privacyConfig) { (Bool) in
            PrivacyManager.didDisplayPrivacyDialog = true
        }
        
        self.dismiss(animated: true) {
            self.completionBlock?()
        }
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "gotoSettingSegue" {
            if let privacySettingsVC = segue.destination as? PrivacySettingsViewController {
                privacySettingsVC.completionBlock = self.completionBlock //Pass along the completion block
            }
        }
    }

}
