//
//  PrivacyManager.swift
//  Dynatrace Mobile
//
//  Created by Nassar, Mohamed on 25.04.18.
//  Copyright © 2018 Dynatrace. All rights reserved.
//

import Foundation
import UIKit
import Dynatrace

class PrivacyManager {
    
    //
    // MARK:- Constants and Keys
    //
    private static let didDisplayPrivacyDialogKey = "com.dynatrace.didDisplayPrivacyDialog"
    
    private static let privacyViewControllerStoryboardKey = "privacyManagerNavVC"
    
    //
    // MARK:- Variables
    //
    static var didDisplayPrivacyDialog:Bool {
        get {
            return UserDefaults.standard.bool(forKey: didDisplayPrivacyDialogKey)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: didDisplayPrivacyDialogKey)
        }
    }
    
    //
    // MARK:- Functions
    //
    class func getUserConsent(presentingViewController:UIViewController?, completion:(() -> Void)? = nil) {
        let gdprStoryBoard = UIStoryboard(name: "GDPRStoryboard", bundle: nil)
        if let privacyNavigationViewController = gdprStoryBoard.instantiateViewController(withIdentifier: privacyViewControllerStoryboardKey) as? UINavigationController, let privacyVC = privacyNavigationViewController.visibleViewController as? PrivacyNoticeViewController {
            privacyVC.completionBlock = completion
            presentingViewController?.present(privacyNavigationViewController, animated: true, completion: nil)
        }
    }
    
}
