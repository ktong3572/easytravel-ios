//
//  PrivacySettingsViewController.swift
//  Dynatrace Mobile
//
//  Created by Nassar, Mohamed on 30.04.18.
//  Copyright © 2018 Dynatrace. All rights reserved.
//

import UIKit
import DynatraceSessionReplay

class PrivacySettingsViewController: UIViewController {
    //
    // MARK:- Constants
    //
    let cornerRadius:CGFloat = 5.0
    
    //
    // MARK:- Outlets
    //
    @IBOutlet var saveButton: UIButton!
    @IBOutlet var closeBarButtonItem: UIBarButtonItem!
    @IBOutlet var frameView: UIView!
    
    //
    // MARK:- Variables
    //
    var isStandalone = false
    
    //
    // MARK:- Completion block to be executed on Save
    //
    var completionBlock: (() -> Void)?
    
    
    private var settingsTableViewController: PrivacySettingsTableViewController?
    
    //
    // MARK:- View lifecycle
    //
    override func viewDidLoad() {
        super.viewDidLoad()

        self.setNavigationBarColor(UIColor.easyTravelOrange, withTextColor: UIColor.white)
        self.saveButton.layer.cornerRadius = cornerRadius
        self.frameView.layer.cornerRadius = cornerRadius
        self.frameView.layer.borderWidth = 0.1
        self.frameView.layer.borderColor = UIColor.lightGray.cgColor
    }

    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
        if !isStandalone {
            self.navigationItem.hidesBackButton = false
            self.navigationItem.leftBarButtonItem = nil
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //
    // MARK: - Navigation
    //
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "embedSegue", let destinationViewController = segue.destination as? PrivacySettingsTableViewController {
            self.settingsTableViewController = destinationViewController
        }
    }
 
    //
    // MARK:- UI Interaction
    //
    @IBAction func saveButtonTapped(_ sender: UIButton) {
        guard let _ = settingsTableViewController,
              let privacySettings = getPrivacySettings(),
              let privacyConfiguration = privacySettings.privacyConfiguration,
              let maskingConfiguration = privacySettings.maskingConfiguration else {return}
            
            try? AgentManager.setMaskingConfiguration(maskingConfiguration)
            Dynatrace.applyUserPrivacyOptions(privacyConfiguration) { (Bool) in
                PrivacyManager.didDisplayPrivacyDialog = true
                if let parent = self.parent, parent.isKind(of: UINavigationController.self) {
                    (parent as! UINavigationController).popViewController(animated: true)
                    //completion block can be ignored in this case as we did not come here from first launch whcih would need a redirect to server settings afterwards
                    //self.completionBlock
                } else {
                    self.dismiss(animated: true, completion: self.completionBlock)
                }
            }
    }
    
    func getPrivacySettings() -> (privacyConfiguration: DTXUserPrivacyOptions?, maskingConfiguration: MaskingConfiguration?)? {
        guard let settingsTableViewController = settingsTableViewController else {
            return nil
        }
        let privacyConfiguration = Dynatrace.userPrivacyOptions()
        let maskingConfiguration: MaskingConfiguration
        
        privacyConfiguration.crashReportingOptedIn = settingsTableViewController.crashReportingSwitch.isOn
        privacyConfiguration.crashReplayOptedIn = settingsTableViewController.crashReplaySwitch.isOn
        
        if !settingsTableViewController.captureAnalyticsDataSwitch.isOn {
            privacyConfiguration.dataCollectionLevel = .off
            maskingConfiguration = MaskingConfiguration(maskingLevelType: .safest)
        } else if !settingsTableViewController.anonymousModeSwitch.isOn {
            privacyConfiguration.dataCollectionLevel = .userBehavior
            maskingConfiguration = MaskingConfiguration(maskingLevelType: .custom)
            try? maskingConfiguration.removeAllRules()
        } else {
            privacyConfiguration.dataCollectionLevel = .performance
            maskingConfiguration = MaskingConfiguration(maskingLevelType: .custom)
            try? maskingConfiguration.removeAllRules()
            try? maskingConfiguration.add(rule: .maskAllInputFields)
            try? maskingConfiguration.addNonMaskedView(viewIds: ["SearchBar", "UISearchBarTextField"])
        }
        return (privacyConfiguration, maskingConfiguration)
    }
    
    @IBAction func closeButtonTapped(_ sender: UIBarButtonItem) {
        self.presentingViewController?.dismiss(animated: true, completion: nil)
    }
    
}

//
// MARK:- The embedded TableViewController
//

class PrivacySettingsTableViewController: UITableViewController {
    
    //
    // MARK: Outlets
    //
    @IBOutlet var captureAnalyticsDataSwitch: UISwitch!
    @IBOutlet var anonymousModeSwitch: UISwitch!
    @IBOutlet var crashReportingSwitch: UISwitch!
    @IBOutlet weak var crashReplaySwitch: UISwitch!
    
    //
    // MARK:- View Lifecycle
    //
    
    override func viewWillAppear(_ animated: Bool) {
        //MARK: Init the toggles
        //If this is the first time, and we did not display the dialog before, then artificially set settings to on
        if !PrivacyManager.didDisplayPrivacyDialog {
            captureAnalyticsDataSwitch.isOn = true
            anonymousModeSwitch.isOn = false
            crashReportingSwitch.isOn = true
            crashReplaySwitch.isOn = true
        } else { //just load the current values
            let privacyConfig = Dynatrace.userPrivacyOptions()
           
            crashReportingSwitch.isOn = privacyConfig.crashReportingOptedIn
            crashReplaySwitch.isOn = privacyConfig.crashReplayOptedIn
            
            let dataCollectionLevel = privacyConfig.dataCollectionLevel
            captureAnalyticsDataSwitch.isOn = dataCollectionLevel != .off
            anonymousModeSwitch.isOn = dataCollectionLevel == .performance
        }
    }
    
    //
    // MARK:- UI Interactions
    //
    
    @IBAction func switchValueChanged(_ sender: UISwitch) {
        if sender == captureAnalyticsDataSwitch {
            if !sender.isOn {
                anonymousModeSwitch.isOn = false
            }
        } else if sender == anonymousModeSwitch  {
            if sender.isOn { //Make sure that if the anonymous button is switched, data analytics is switched on as well
                captureAnalyticsDataSwitch.isOn = true
            }
        } else if sender == crashReportingSwitch {
            crashReplaySwitch.isOn = sender.isOn    //disable replay when ther eis no crash reporting and re-enable again when reporting is enabled
        }
    }
    
}
