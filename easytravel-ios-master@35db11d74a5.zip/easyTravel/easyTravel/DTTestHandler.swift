class DTTestHandler {

    private weak var window: UIWindow?
    private let newSessionNotificationName = NSNotification.Name("DTXNewSessionNotification")
    private let serverConfigurationChangedNotificationName = NSNotification.Name("DTXServerConfigurationChangedNotification")
    private let counter = DTTestHandlerCounter(maximumCount: 1)
    private var newJourneyPresented = false

    func handleTestIfNeeded(_ window: UIWindow?) {
        guard isRunningTest else { return }
        self.window = window
        subscribeToNewSessionNotification()
    }

    private func presentNewJourneyAvailable() {
        guard isRunningLoadGeneratorTest else { return }

        newJourneyPresented = true
        let alert = UIAlertController(title: "Customer loyalty program", message: "There’re new special offers waiting for you!", preferredStyle: .alert)
        let action = UIAlertAction(title: "I want them!", style: .default) { _ in
            alert.dismiss(animated: false)
        }
        let dismissAction = UIAlertAction(title: "Dismiss", style: .cancel) { _ in
            alert.dismiss(animated: false)
        }

        alert.addAction(action)
        alert.addAction(dismissAction)
        present(alertViewController: alert)
    }

    @objc private func didReceiveNewSessionNotification() {
        guard newJourneyPresented == false else { return }
        counter.add {
            self.presentNewJourneyAvailable()
        }
    }

    private func subscribeToNewSessionNotification() {
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(didReceiveNewSessionNotification),
                                               name: newSessionNotificationName,
                                               object: nil)

        NotificationCenter.default.addObserver(self,
                                               selector: #selector(didReceiveNewSessionNotification),
                                               name: serverConfigurationChangedNotificationName,
                                               object: nil)
    }

    private func unsubscribeNewSessionNotification() {
        NotificationCenter.default.removeObserver(self, name: newSessionNotificationName, object: nil)
        NotificationCenter.default.removeObserver(self, name: serverConfigurationChangedNotificationName, object: nil)
    }

    private var isRunningTest: Bool {
        return ProcessInfo.processInfo.environment["XCTestConfigurationFilePath"] != nil
    }

    private var isRunningLoadGeneratorTest: Bool {
        #if LOAD_GENERATOR_TEST
            return true
        #else
            return false
        #endif
    }

    private func present(alertViewController: UIViewController) {
        let rootViewController = window?.rootViewController
        let presentingViewController = rootViewController?.presentedViewController ?? rootViewController
        presentingViewController?.present(alertViewController, animated: false, completion: {
            self.unsubscribeNewSessionNotification()
        })
    }
}

private class DTTestHandlerCounter {
    private var counter: Int = 0
    private var maximumCount: Int

    init(maximumCount: Int) {
        self.maximumCount = maximumCount
    }

    func add(completion: () -> Void) {
        counter += 1
        if counter == maximumCount {
            completion()
            counter = 0
        }
    }
}
