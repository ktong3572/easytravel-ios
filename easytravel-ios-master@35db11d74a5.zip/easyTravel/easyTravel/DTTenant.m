//
//  DTTenant.m
//  easyTravel
//
//  Created by Patrick Haruksteiner on 2012-01-05.
//  Copyright (c) 2012 dynaTrace software. All rights reserved.
//

#import "DTTenant.h"

@implementation DTTenant

@end
